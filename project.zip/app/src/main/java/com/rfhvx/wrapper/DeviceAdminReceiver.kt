package com.rfhvx.wrapper
import android.app.admin.DeviceAdminReceiver
class DeviceAdminReceiver : DeviceAdminReceiver()
