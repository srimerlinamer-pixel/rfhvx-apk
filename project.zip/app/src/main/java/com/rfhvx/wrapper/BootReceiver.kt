package com.rfhvx.wrapper
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        LockService.start(context)
        if (LockService.isLocked(context)) LockService.showOverlay(context)
    }
}
