package com.rfhvx.wrapper
import android.content.Context
import android.webkit.JavascriptInterface
class Bridge(private val ctx: Context) {
    @JavascriptInterface fun startLockMode(message: String, pass: String) {
        (ctx as? MainActivity)?.runOnUiThread {
            LockService.setLock(ctx, message, pass)
            LockService.showOverlay(ctx)
        }
    }
    @JavascriptInterface fun stopLockMode() {
        (ctx as? MainActivity)?.runOnUiThread { LockService.unlock(ctx) }
    }
    @JavascriptInterface fun isLocked(): Boolean = LockService.isLocked(ctx)
}
