package com.rfhvx.wrapper
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.webkit.PermissionRequest
import androidx.appcompat.app.AppCompatActivity
class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) { request.grant(request.resources) }
        }
        webView.addJavascriptInterface(Bridge(this), "AndroidLock")
        webView.loadUrl("file:///android_asset/index.html")
    }
    override fun onBackPressed() {
        if (LockService.isLocked(this)) { LockService.showOverlay(this); return }
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
